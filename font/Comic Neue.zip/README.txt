Comic Neue is an original reinterpretation of the classic, Comic Sans.

Comic Neue aspires to be the casual script choice for everyone, including the typographically savvy. The squashed, wonky, and weird glyphs of Comic Sans have been beaten into shape – while maintaining the honesty that made Comic Sans so popular.

**Don't miss the project homepage, [comicneue.com](http://comicneue.com)**

The Comic Neue project was initiated by Craig Rozynski, a designer living in Australia and Japan. To contribute or report any issues, see [github.com/crozynski/comicneue](https://github.com/crozynski/comicneue)